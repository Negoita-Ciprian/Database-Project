-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gazdă: 127.0.0.1
-- Timp de generare: ian. 18, 2023 la 09:27 AM
-- Versiune server: 10.4.25-MariaDB
-- Versiune PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `javaapplication1`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `adresa_inmatriculare`
--

CREATE TABLE `adresa_inmatriculare` (
  `ID_Adresa` int(11) NOT NULL,
  `Judet` varchar(255) NOT NULL,
  `Oras` varchar(255) NOT NULL,
  `Strada` varchar(255) NOT NULL,
  `Numar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `adresa_inmatriculare`
--

INSERT INTO `adresa_inmatriculare` (`ID_Adresa`, `Judet`, `Oras`, `Strada`, `Numar`) VALUES
(1, 'Vrancea', 'Gugesti', 'Mihai Viteazul ', '22'),
(2, 'Vrancea', 'Focsani', 'Lalelelor', '44'),
(3, 'Dambovita', 'Targoviste', 'Maresalul Averescu', '64'),
(4, 'Bucuresti', 'Bucuresti', 'Florilor', '876'),
(5, 'Braila', 'Braila', 'Tufei', '77'),
(6, 'Calarasi', 'Calarasi', 'Narciselor', '88');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `marca`
--

CREATE TABLE `marca` (
  `ID_Marca` int(11) NOT NULL,
  `Nume` varchar(255) NOT NULL,
  `ID_Model` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `marca`
--

INSERT INTO `marca` (`ID_Marca`, `Nume`, `ID_Model`) VALUES
(1, 'Volkswagen', 1),
(2, 'Mercedes', 2),
(3, 'Opel', 3),
(4, 'Renault', 4),
(5, 'Volkswagen', 5),
(6, 'BMW', 6);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `masina`
--

CREATE TABLE `masina` (
  `ID_Masina` int(11) NOT NULL,
  `ID_Proprietar` int(11) NOT NULL,
  `ID_Adresa` int(11) NOT NULL,
  `ID_Numar` int(11) NOT NULL,
  `ID_Marca` int(11) NOT NULL,
  `Numar_Locuri` int(30) NOT NULL,
  `Serie_VIN` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `masina`
--

INSERT INTO `masina` (`ID_Masina`, `ID_Proprietar`, `ID_Adresa`, `ID_Numar`, `ID_Marca`, `Numar_Locuri`, `Serie_VIN`) VALUES
(1, 1, 1, 1, 1, 5, '11111111'),
(2, 2, 2, 2, 2, 5, '22222222'),
(3, 3, 3, 3, 3, 5, '33333333'),
(4, 4, 4, 4, 4, 5, '44444444'),
(5, 5, 5, 5, 5, 5, '55555555'),
(6, 6, 6, 6, 6, 5, '55555555');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `model`
--

CREATE TABLE `model` (
  `ID_Model` int(11) NOT NULL,
  `Nume` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `model`
--

INSERT INTO `model` (`ID_Model`, `Nume`) VALUES
(1, 'Bora'),
(2, 'G-Class'),
(3, 'Astra'),
(4, 'Fluence'),
(5, 'Jetta'),
(6, 'X6');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `numar_masina`
--

CREATE TABLE `numar_masina` (
  `ID_Numar` int(11) NOT NULL,
  `Judet` varchar(255) NOT NULL,
  `Numar` varchar(255) NOT NULL,
  `Preferential` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `numar_masina`
--

INSERT INTO `numar_masina` (`ID_Numar`, `Judet`, `Numar`, `Preferential`) VALUES
(1, 'VN', '18', 'NGT'),
(2, 'VN', '22', 'JSM'),
(3, 'DB', '09', 'PDF'),
(4, 'B', '212', 'PTR'),
(5, 'BR', '07', 'DDS'),
(6, 'CL', '65', 'MCN');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `proprietar`
--

CREATE TABLE `proprietar` (
  `ID_Proprietar` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `prenume` varchar(255) NOT NULL,
  `cnp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `proprietar`
--

INSERT INTO `proprietar` (`ID_Proprietar`, `nume`, `prenume`, `cnp`) VALUES
(1, 'Negoita', 'Ciprian', '5010818394422'),
(2, 'Antal', 'Jasmyna', '6010812887645'),
(3, 'Plavie', 'Dan', '5010421465322'),
(4, 'Petroiu', 'Larisa', '6010456772311'),
(5, 'Dumitrache', 'Darius', '5011223568788'),
(6, 'Macinic', 'Bogdan', '5010608896542');

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `adresa_inmatriculare`
--
ALTER TABLE `adresa_inmatriculare`
  ADD PRIMARY KEY (`ID_Adresa`);

--
-- Indexuri pentru tabele `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`ID_Marca`),
  ADD KEY `ID_Model` (`ID_Model`);

--
-- Indexuri pentru tabele `masina`
--
ALTER TABLE `masina`
  ADD PRIMARY KEY (`ID_Masina`),
  ADD KEY `ID_Proprietar` (`ID_Proprietar`),
  ADD KEY `ID_Adresa` (`ID_Adresa`),
  ADD KEY `ID_Numar` (`ID_Numar`),
  ADD KEY `ID_Marca` (`ID_Marca`);

--
-- Indexuri pentru tabele `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`ID_Model`);

--
-- Indexuri pentru tabele `numar_masina`
--
ALTER TABLE `numar_masina`
  ADD PRIMARY KEY (`ID_Numar`);

--
-- Indexuri pentru tabele `proprietar`
--
ALTER TABLE `proprietar`
  ADD PRIMARY KEY (`ID_Proprietar`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `adresa_inmatriculare`
--
ALTER TABLE `adresa_inmatriculare`
  MODIFY `ID_Adresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pentru tabele `marca`
--
ALTER TABLE `marca`
  MODIFY `ID_Marca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pentru tabele `masina`
--
ALTER TABLE `masina`
  MODIFY `ID_Masina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pentru tabele `numar_masina`
--
ALTER TABLE `numar_masina`
  MODIFY `ID_Numar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pentru tabele `proprietar`
--
ALTER TABLE `proprietar`
  MODIFY `ID_Proprietar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constrângeri pentru tabele eliminate
--

--
-- Constrângeri pentru tabele `marca`
--
ALTER TABLE `marca`
  ADD CONSTRAINT `marca_ibfk_1` FOREIGN KEY (`ID_Model`) REFERENCES `model` (`ID_Model`);

--
-- Constrângeri pentru tabele `masina`
--
ALTER TABLE `masina`
  ADD CONSTRAINT `masina_ibfk_1` FOREIGN KEY (`ID_Proprietar`) REFERENCES `proprietar` (`ID_Proprietar`),
  ADD CONSTRAINT `masina_ibfk_2` FOREIGN KEY (`ID_Adresa`) REFERENCES `adresa_inmatriculare` (`ID_Adresa`),
  ADD CONSTRAINT `masina_ibfk_3` FOREIGN KEY (`ID_Numar`) REFERENCES `numar_masina` (`ID_Numar`),
  ADD CONSTRAINT `masina_ibfk_4` FOREIGN KEY (`ID_Marca`) REFERENCES `marca` (`ID_Marca`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
